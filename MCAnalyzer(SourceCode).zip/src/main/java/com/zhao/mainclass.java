package com.zhao;
import com.zhao.view.BeginUi;
public class mainclass {
    public static void main(String[] args) {
        new BeginUi();
    }
}
