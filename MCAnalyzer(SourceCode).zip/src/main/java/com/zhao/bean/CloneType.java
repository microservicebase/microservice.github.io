package com.zhao.bean;

import java.util.Arrays;
import java.util.List;

public class CloneType implements  Comparable<CloneType>{
    private String id;
    private String typeId;
    private List<String> clusterInfo;
    private List<String> cloneInfo;
    private String cloneType;
    private String note;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getCloneInfo() {
        return cloneInfo;
    }

    public void setCloneInfo(List<String> cloneInfo) {
        this.cloneInfo = cloneInfo;
    }

    public String getCloneType() {
        return cloneType;
    }

    public void setCloneType(String cloneType) {
        this.cloneType = cloneType;
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public List<String> getClusterInfo() {
        return clusterInfo;
    }

    public void setClusterInfo(List<String> clusterInfo) {
        this.clusterInfo = clusterInfo;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public CloneType() {

    }

    public CloneType(String id, String typeId, List<String> clusterInfo, List<String> cloneInfo, String cloneType, String note) {
        this.id = id;
        this.typeId = typeId;
        this.clusterInfo = clusterInfo;
        this.cloneInfo = cloneInfo;
        this.cloneType = cloneType;
        this.note = note;
    }

    @Override
    public String toString() {
        return "CloneType{" +
                "id='" + id + '\'' +
                ", typeId='" + typeId + '\'' +
                ", clusterInfo=" + clusterInfo +
                ", cloneInfo=" + cloneInfo +
                ", cloneType='" + cloneType + '\'' +
                ", note='" + note + '\'' +
                '}';
    }


    @Override
    public int compareTo(CloneType o) {
       int res = this.getTypeId().compareTo(o.getTypeId()) ;
       return res;
    }
}
