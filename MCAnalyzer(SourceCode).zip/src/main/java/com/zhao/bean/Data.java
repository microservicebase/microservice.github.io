package com.zhao.bean;

import java.util.List;

public class Data {
    private String id;
    private List<String> clone_pair;
    private String clone_type;
    private String cluster_id;
    private List<String> file_mark;
    private String clone_mark;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getClone_pair() {
        return clone_pair;
    }

    public void setClone_pair(List<String> clone_pair) {
        this.clone_pair = clone_pair;
    }

    public String getClone_type() {
        return clone_type;
    }

    public void setClone_type(String clone_type) {
        this.clone_type = clone_type;
    }

    public String getCluster_id() {
        return cluster_id;
    }

    public void setCluster_id(String cluster_id) {
        this.cluster_id = cluster_id;
    }

    public List<String> getFile_mark() {
        return file_mark;
    }

    public void setFile_mark(List<String> file_mark) {
        this.file_mark = file_mark;
    }

    public String getClone_mark() {
        return clone_mark;
    }

    public void setClone_mark(String clone_mark) {
        this.clone_mark = clone_mark;
    }



    @Override
    public String toString() {
        return "Data{" +
                "id='" + id + '\'' +
                ", clone_pair='" + clone_pair + '\'' +
                ", clone_type='" + clone_type + '\'' +
                ", cluster_id='" + cluster_id + '\'' +
                ", file_mark='" + file_mark + '\'' +
                ", clone_mark='" + clone_mark + '\'' +
                '}';
    }
}
