package com.zhao.bean;

public class FileType {
    private String id;
    private String fileName;
    private String filePath;
    private String dataType;

    public FileType() {

    }

    public FileType(String id, String fileName, String filePath, String fileType,String dataType) {
        this.id = id;
        this.fileName = fileName;
        this.filePath = filePath;
        this.dataType = dataType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


    public String getDataType() {return dataType;}

    public void setDataType(String dataType) {this.dataType = dataType;}

    @Override
    public String toString() {
        return "FileType{" +
                "id='" + id + '\'' +
                ", fileName='" + fileName + '\'' +
                ", filePath='" + filePath + '\'' +
                ", dataType='" + dataType + '\'' +
                '}';
    }
}
