package com.zhao.view;
import com.zhao.cloneClassify.CloneAnalysis;
import com.zhao.cloneClassify.JsonCreate;

import javax.imageio.stream.FileCacheImageInputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
public class BeginUi implements ActionListener {
    private JFrame jf = new JFrame("Microservice code clone analysis");
    private Container container = jf.getContentPane();
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private Dimension sc = toolkit.getScreenSize();
    private JLabel title = new JLabel("Welcome to use this tool, in order to ensure normal use, please be sure to read the user manual to understand the requirements and functions ");
    private JTextField filePath = new JTextField("");
    private JFileChooser jFileChooser = new JFileChooser();
    private JButton button1 = new JButton("Divide clones");
    private JButton button2 = new JButton("clone detection");
    private JButton button3 = new JButton("Please select a directory to analyze");

    private JButton button4 = new JButton("Attribution label");
    private JButton button5 = new JButton("label data analysis");

    public BeginUi(){
        container.setLayout(null);
        jf.setSize(1300,400);
        jf.setLocation((sc.width - 1000) / 2, (sc.height - 618) / 2);
        jf.setResizable(false);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        container.setVisible(true);
        title.setBounds(100,50,1100,150);
        title.setForeground(Color.BLACK);
        title.setBackground(Color.lightGray);
        title.setOpaque(true);
        button2.setBounds(100,270,150,30);
        button3.setBounds(100,220,180,30);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button1.setBounds(270,270,150,30);
        button1.addActionListener(this);
        button4.setBounds(440,270,150,30);
        button4.addActionListener(this);
        button5.setBounds(610,270,150,30);
        button5.addActionListener(this);

        filePath.setBounds(300,220,900,30);
        container.add(title);
        container.add(button3);
        container.add(button2);
        container.add(filePath);
        container.add(button1);
        container.add(button4);
        container.add(button5);
    }
    public void cleanPath(){
        this.filePath.setText("");
    }
    public static void winMessage(String str) {
        JOptionPane.showMessageDialog(null, str, "warning",
                JOptionPane.INFORMATION_MESSAGE);
    }
    @Override
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource() == this.button3){
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new File("."));
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            fileChooser.setMultiSelectionEnabled(false);
            int result = fileChooser.showOpenDialog(jf);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                filePath.setText(file.getAbsolutePath());
            }
        }
        if(ac.getSource() == this.button1){
            String path = filePath.getText();
            if(path.equals("")){
                BeginUi.winMessage("You haven't selected a folder to analyze！");
            }else{
                new CloneAnalysisUi(path);
                this.jf.dispose();
            }
        }
        if (ac.getSource() == this.button2){
            String path = filePath.getText();
            if(path.equals("")){
                BeginUi.winMessage("You haven't selected a folder to analyze！");
            }else{
                new CodeCloneDetectUi(path);
                this.jf.dispose();
            }
        }
        if(ac.getSource() == this.button4){
            String path = filePath.getText();
            if(path.equals("")){
                BeginUi.winMessage("You haven't selected a folder to analyze！");
            }else{
                new FileClassifyUi(path);
                this.jf.dispose();
            }
        }
        if(ac.getSource() == this.button5){
            String path = filePath.getText();
            JsonCreate jsonCreate = new JsonCreate(path);

        }

    }
}
