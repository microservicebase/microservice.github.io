package com.zhao.view;

import com.alibaba.fastjson.JSON;
import com.zhao.bean.CloneType;
import com.zhao.cloneClassify.CodeLevelClassify;
import com.zhao.util.FileWriterUtil;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CloneClassifyUi implements ActionListener, ListSelectionListener {
    private String path;
    private int loc;
    int choose;
    private List<CloneType> allClone;
    private CodeLevelClassify codeLevelClassify = new CodeLevelClassify();
    private List<String> res = new ArrayList<>();
    FileWriterUtil fileWriterUtil  = new FileWriterUtil();

    private JFrame jf = new JFrame("Function Type Label");
    private Container container = jf.getContentPane();
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private Dimension sc = toolkit.getScreenSize();

    private JList list= new JList();
    private ScrollPane scrollPane = new ScrollPane();

    private JLabel label1 = new JLabel("Check function");
    private JButton button1 = new JButton("Random");
    private JButton button2 = new JButton("Current");

    private JLabel label2 = new JLabel("Enter Label");
    private JTextField textField1 = new JTextField("");
    private JButton button3 = new JButton("Confirm");

    private JLabel label3 = new JLabel("Note");
    private JTextField textField2 = new JTextField("");
    private JButton button4 = new JButton("Confirm");

    private JButton button5 = new JButton("Previous");
    private JButton button6 = new JButton("Next");
    private JButton button7 = new JButton("Output");
    private JButton button8 = new JButton("Return");

    private JButton button9 = new JButton("Start");

    public CloneClassifyUi(String path){
        loc = 0;
        this.path = path;
        allClone = codeLevelClassify.getInitClone(path);


        container.setLayout(null);
        jf.setSize(900, 700);
        jf.setLocation((sc.width - 1000) / 2, (sc.height - 618) / 2);
        jf.setResizable(false);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        list.setBounds(50,30,800,300);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.addListSelectionListener(this);
        scrollPane.setBounds(50,30,800,300);
        scrollPane.add(list);

        label1.setBounds(100,350,100,30);
        button1.setBounds(220,350,100,30);
        button2.setBounds(340,350,100,30);

        label2.setBounds(100,400,100,30);
        textField1.setBounds(220,400,100,30);
        button3.setBounds(340,400,100,30);

        label3.setBounds(100,450,100,30);
        textField2.setBounds(220,450,100,30);
        button4.setBounds(340,450,100,30);

        button5.setBounds(220,550,100,30);
        button6.setBounds(340,550,100,30);
        button7.setBounds(220,600,100,30);
        button8.setBounds(340,600,100,30);
        button5.setEnabled(false);
        if (allClone.size() == 1){
            button6.setEnabled(false);
        }

        button9.setBounds(270,500,100,30);


        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);
        button6.addActionListener(this);
        button7.addActionListener(this);
        button8.addActionListener(this);
        button9.addActionListener(this);

        container.add(label1);
        container.add(button1);
        container.add(button2);
        container.add(label2);
        container.add(textField1);
        container.add(button3);
        container.add(label3);
        container.add(textField2);
        container.add(button4);
        container.add(button5);
        container.add(button6);
        container.add(button7);
        container.add(button8);
        container.add(button9);
        jf.add(scrollPane);


    }

    @Override
    public void actionPerformed(ActionEvent ac) {
        if (ac.getSource() == button1){
            int max = allClone.get(loc).getClusterInfo().size();
            Random random = new Random();
            int ranNum = random.nextInt(max) % (max - 0 + 1) + 0;

            String location = allClone.get(loc).getClusterInfo().get(ranNum).split("----")[1] + "---" + allClone.get(loc).getClusterInfo().get(ranNum).split("----")[2];
            winMessage("Note that the function location is" + location);

            String file = allClone.get(loc).getClusterInfo().get(ranNum).split("----")[0];
            try {
                Desktop.getDesktop().open(new File(file));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (ac.getSource() == button2){
            int select = list.getSelectedIndex();

            String location = allClone.get(loc).getClusterInfo().get(select).split("----")[1] + "---" + allClone.get(loc).getClusterInfo().get(select).split("----")[2];
            winMessage("Note that the function location is" + location);

            String file = allClone.get(loc).getClusterInfo().get(select).split("----")[0];
            try {
                Desktop.getDesktop().open(new File(file));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (ac.getSource() == button9){
            list.setListData(allClone.get(loc).getClusterInfo().toArray());
            list.setSelectedIndex(0);
            choose = list.getSelectedIndex();
        }
        if (ac.getSource() == button3){
            String type = textField1.getText();
            allClone.get(loc).setCloneType(type);
        }
        if (ac.getSource() == button4){
            String note = textField2.getText();
            allClone.get(loc).setNote(note);
        }
        if (ac.getSource() == button5){
            loc--;
            list.setListData(allClone.get(loc).getClusterInfo().toArray());
            textField1.setText(allClone.get(loc).getCloneType());
            textField2.setText(allClone.get(loc).getNote());

            if (loc == 0){
                this.button5.setEnabled(false);
            }
            if (loc <= allClone.size() - 1){
                this.button6.setEnabled(true);
            }
        }
        if (ac.getSource() == button6){
            loc++;
            list.setListData(allClone.get(loc).getClusterInfo().toArray());
            textField1.setText(allClone.get(loc).getCloneType());
            textField2.setText(allClone.get(loc).getNote());

            if (loc >= 1){
                this.button5.setEnabled(true);
            }
            if (loc == allClone.size() - 1){
                this.button6.setEnabled(false);
            }
        }

        if(ac.getSource() == button7){
            String temp;
            res.clear();
            for (CloneType c : allClone){
                temp = JSON.toJSONString(c);
                res.add(temp);
            }
            fileWriterUtil.writeJson(res,path,"codelevel-4t-simple");
        }
        if(ac.getSource() == button8){
            new BeginUi();
            this.jf.dispose();
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {

    }

    public static void winMessage(String str) {
        JOptionPane.showMessageDialog(null, str, "warning",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
