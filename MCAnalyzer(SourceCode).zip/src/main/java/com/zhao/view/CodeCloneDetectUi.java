package com.zhao.view;
import com.zhao.clone_detect.NicadIntegration;
import com.zhao.util.ProInfoUtil;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class CodeCloneDetectUi implements ActionListener {
    private String path;
    int current_version = 0;
    int flag = 0;
    ProInfoUtil proInfoUtil = new ProInfoUtil();
    NicadIntegration nicadIntegration = new NicadIntegration();
    File current = new File("");
    String[] allVersion;
    private JFrame jf = new JFrame("clone detection");
    private Container container = jf.getContentPane();
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private Dimension sc = toolkit.getScreenSize();
    private JLabel jLabel1 = new JLabel("All versions of the project are as follows");
    private JTextField jTextField1 = new JTextField();
    private JLabel jLabel2 = new JLabel("current version");
    private JTextField jTextField2 = new JTextField();
    private JButton jButton1 = new JButton("Previous");
    private JButton jButton2 = new JButton("next");
    private JButton jButton3 = new JButton("Start detecting clones");
    private JButton jButton4 = new JButton("One-click analysis of all versions");
    private JButton jButton5 = new JButton("return");
    public CodeCloneDetectUi(String path) {
        this.path = path;
        allVersion = proInfoUtil.projectVersion(path);

        container.setLayout(null);
        jf.setSize(1300, 400);
        jf.setLocation((sc.width - 1000) / 2, (sc.height - 618) / 2);
        jf.setResizable(false);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jLabel1.setBounds(100,50,180,30);
        jLabel1.setBackground(Color.lightGray);
        jLabel1.setForeground(Color.BLACK);
        jLabel1.setOpaque(true);
        jTextField1.setBounds(100,100,1100,30);
        jTextField1.setText(proInfoUtil.showString(proInfoUtil.projectVersion(path),0));
        jLabel2.setBounds(100,150,100,30);
        jTextField2.setBounds(225,150,150,30);
        jButton1.setBounds(400,150,150,30);
        jButton2.setBounds(575,150,150,30);
        jButton3.setBounds(750,150,150,30);
        jButton1.setEnabled(false);
        jTextField2.setText(allVersion[current_version]);
        jButton4.setBounds(100,250,150,30);
        jButton5.setBounds(300,250,150,30);
        jButton1.addActionListener(this);
        jButton2.addActionListener(this);
        jButton3.addActionListener(this);
        jButton4.addActionListener(this);
        jButton5.addActionListener(this);
        container.add(jLabel1);
        container.add(jLabel2);
        container.add(jTextField1);
        container.add(jTextField2);
        container.add(jButton1);
        container.add(jButton2);
        container.add(jButton3);
        container.add(jButton4);
        container.add(jButton5);
        if(allVersion.length == 1){
            jButton1.setEnabled(false);
            jButton2.setEnabled(false);
        }

    }
    @Override
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource() == jButton1){
            current_version--;
            jTextField2.setText(allVersion[current_version]);
            jTextField1.setText(proInfoUtil.showString(allVersion,current_version));
            if(current_version == 0){
                this.jButton1.setEnabled(false);
            }
            if(current_version <= (allVersion.length - 1)){
                this.jButton2.setEnabled(true);
            }
        }
        if(ac.getSource() == jButton2){
            current_version++;
            jTextField2.setText(allVersion[current_version]);
            jTextField1.setText(proInfoUtil.showString(allVersion,current_version));
            if(current_version >= 1){
                this.jButton1.setEnabled(true);
            }
            if(current_version == allVersion.length -1){
                this.jButton2.setEnabled(false);
            }
        }
        if(ac.getSource() == jButton3){
            flag = 0;
            nicadIntegration.clearPro(path + "\\" + allVersion[current_version],1);
            System.out.println(path + "  path");
            System.out.println(current.getAbsolutePath() + "   current");
            String target = "../../../2_projects/" + proInfoUtil.getProName(path) + "/" + allVersion[current_version] + "/" + "sourcecode";
            setButton(false);
            winMessage(allVersion[current_version] + "Version clone detection, button is unavailable, resume after detection");
            cloneDetect(target);
            if(flag >= 3){
                if (flag == 3){
                    int cut = nicadIntegration.cutFile(path + "\\" + allVersion[current_version] );
                    if (cut==4){
                        winMessage( "The clone detection was successful and the results are stored in" + path + "\\" + allVersion[current_version] + "path");
                    }
                    System.out.println(cut);
                }else{
                    winMessage(allVersion[current_version] +  " Error in version detection, please check the item");
                }
            }
            setButton(true);
        }
        if(ac.getSource() == jButton4){
            List<String> success = new ArrayList<>();
            List<String> fail = new ArrayList<>();
            setButton(false);
            winMessage("The clone detection is in progress (it may take a long time), the button is unavailable, and it will resume after the detection is completed.");
            for(String s : allVersion){
                flag = 0;
                nicadIntegration.clearPro(path + "\\" + s,1);
                String target = "../../../2_projects/" + proInfoUtil.getProName(path) + "/" + s + "/" + "sourcecode";
                cloneDetect(target);
                if(flag >= 3){
                    if (flag == 3){
                        int cut = nicadIntegration.cutFile(path + "\\" + s);
                        if (cut==4){
                            success.add(s);
                            System.out.println(s + cut);
                        }else{
                            fail.add(s);
                        }
                    }else{
                        fail.add(s);
                    }
                }
            }
            String resultInfo = "";
            if(success.size() == allVersion.length){
                resultInfo = "Detected successful version：" + getString(success) + "\nNo detection failed version";
            }else if(success.size() < allVersion.length){
                resultInfo = "Detected successful version：" + getString(success) + "\nDetect failed version：gravitee-3.5.0" ;
            }
            winMessage(resultInfo);
            setButton(true);
        }
        if (ac.getSource() == jButton5){
            this.jf.dispose();
            new BeginUi();
        }
    }
    public static void winMessage(String str) {
        JOptionPane.showMessageDialog(null, str, "warning",
                JOptionPane.INFORMATION_MESSAGE);
    }
    public void cloneDetect(String target){
        nicadIntegration.modfiybash( current.getAbsolutePath()+ "\\CygWin\\etc\\"+"bash.bashrc",target,"type1-report");
        flag += nicadIntegration.run_bat(current.getAbsolutePath());
        nicadIntegration.modfiybash(current.getAbsolutePath()+ "\\CygWin\\etc\\"+"bash.bashrc",target,"type2-report");
        flag += nicadIntegration.run_bat(current.getAbsolutePath());
        nicadIntegration.modfiybash(current.getAbsolutePath()+ "\\CygWin\\etc\\"+"bash.bashrc",target,"type3-2-report");
        flag += nicadIntegration.run_bat(current.getAbsolutePath());
    }
    public void setButton(boolean b){
        if(current_version == 0){
            jButton2.setEnabled(b);
            jButton3.setEnabled(b);
            jButton4.setEnabled(b);
            jButton5.setEnabled(b);
        }else if(current_version == allVersion.length - 1){
            jButton1.setEnabled(b);
            jButton3.setEnabled(b);
            jButton4.setEnabled(b);
            jButton5.setEnabled(b);
        }else{
            jButton1.setEnabled(b);
            jButton2.setEnabled(b);
            jButton3.setEnabled(b);
            jButton4.setEnabled(b);
            jButton5.setEnabled(b);
        }
    }
    public String getString(List<String> ls){
        String res = "";
        for (String s : ls){
            res = res + s + "  ";
        }
        return res;
    }
}
