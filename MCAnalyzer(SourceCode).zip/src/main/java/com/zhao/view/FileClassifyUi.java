package com.zhao.view;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhao.bean.FileType;
import com.zhao.cloneClassify.FileLevelClassify;
import com.zhao.util.FileWriterUtil;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class FileClassifyUi implements ActionListener {
    String path;
    FileLevelClassify fileLevelClassify = new FileLevelClassify();
    List<FileType> allFile = new ArrayList<>();
    List<String> res = new ArrayList<>();
    FileWriterUtil fileWriterUtil = new FileWriterUtil();
    int loc = 0;

    private JFrame jf = new JFrame("File Type Label");
    private Container container = jf.getContentPane();
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private Dimension sc = toolkit.getScreenSize();

    private JLabel label1 = new JLabel("File Path");
    private JTextField textField1 = new JTextField();

    private JLabel label2 = new JLabel("File Checking");
    private JButton button1 = new JButton("Open File");


    private JLabel label5 = new JLabel("Type Labeling");
    private JTextField textField4 = new JTextField();
    private JButton button11 = new JButton("DPFile");
    private JButton button12 = new JButton("DRFile");
    private JButton button13 = new JButton("DIFile");


    private JButton button6 = new JButton("Previous");
    private JButton button7 = new JButton("Next");
    private JButton button9 = new JButton("Output Json File");
    private JButton button10 = new JButton("Functoin Level Label");
    private JButton button5 = new JButton("Return");

    private  JLabel label3 = new JLabel("Current Project");
    private JTextField textField3 = new JTextField();
    private JButton button8 = new JButton("Start Label");


    public FileClassifyUi(String path){
        this.path = path;
        container.setLayout(null);
        allFile = fileLevelClassify.getInitFile(path);
        jf.setSize(800, 500);
        jf.setLocation((sc.width - 1000) / 2, (sc.height - 618) / 2);
        jf.setResizable(false);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label1.setBounds(100,100,100,30);
        textField1.setBounds(200,100,500,30);

        label2.setBounds(100,150,100,30);
        button1.setBounds(230,150,100,30);
        button1.setVisible(false);
        button1.addActionListener(this);


        label5.setBounds(100,200,100,30);
        textField4.setBounds(200,200,100,30);
        button11.setBounds(320,200,100,30);
        button12.setBounds(440,200,100,30);
        button13.setBounds(560,200,100,30);
        button12.setVisible(false);
        button13.setVisible(false);
        button11.setVisible(false);
        button12.addActionListener(this);
        button13.addActionListener(this);
        button11.addActionListener(this);


        button6.setBounds(320,300,100,30);
        button7.setBounds(440,300,100,30);
        button9.setBounds(270,350,150,30);
        button10.setBounds(440,350,150,30);
        button5.setBounds(380,400,100,30);
        button6.setVisible(false);
        button7.setVisible(false);
        button9.setVisible(false);
        button10.setVisible(false);
        button6.addActionListener(this);
        button7.addActionListener(this);
        button9.addActionListener(this);
        button10.addActionListener(this);
        button5.addActionListener(this);

        label3.setBounds(100,50,100,30);
        textField3.setBounds(200,50,150,30);
        textField3.setText(path.split("\\\\")[path.split("\\\\").length - 2]);
        button8.setBounds(400,50,100,30);
        button8.addActionListener(this);

        container.add(label1);
        container.add(textField1);
        container.add(label2);
        container.add(button1);
        container.add(button6);
        container.add(button7);
        container.add(label3);
        container.add(textField3);
        container.add(button8);
        container.add(button9);
        container.add(button10);
        container.add(label5);
        container.add(textField4);
        container.add(button11);
        container.add(button12);
        container.add(button13);
        container.add(button5);
    }

    @Override
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource() ==  button8){
            button1.setVisible(true);
            button6.setVisible(true);
            button7.setVisible(true);
            button9.setVisible(true);
            button10.setVisible(true);
            button11.setVisible(true);
            button12.setVisible(true);
            button13.setVisible(true);
            button6.setEnabled(false);
            button8.setEnabled(false);
            loc = 0;
            textField1.setText(allFile.get(loc).getFilePath());
        }

        if(ac.getSource() == button6){
            loc--;
            textField1.setText(allFile.get(loc).getFilePath());
            textField4.setText(allFile.get(loc).getDataType());
            if (loc == 0){
                this.button6.setEnabled(false);
            }
            if (loc <= allFile.size() - 1){
                this.button7.setEnabled(true);
            }
        }
        if(ac.getSource() == button7){
            loc++;
            textField1.setText(allFile.get(loc).getFilePath());
            textField4.setText(allFile.get(loc).getDataType());
            if (loc >= 1){
                this.button6.setEnabled(true);
            }
            if (loc == allFile.size() - 1){
                this.button7.setEnabled(false);
            }
        }

        if(ac.getSource() == button11){
            allFile.get(loc).setDataType("core");
            textField4.setText(allFile.get(loc).getDataType());
        }
        if(ac.getSource() == button12){
            allFile.get(loc).setDataType("support");
            textField4.setText(allFile.get(loc).getDataType());
        }
        if(ac.getSource() == button13){
            allFile.get(loc).setDataType("other");
            textField4.setText(allFile.get(loc).getDataType());
        }
        if(ac.getSource() == button1){
            try {
                Desktop.getDesktop().open(new File(textField1.getText()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(ac.getSource() ==button9){
            String temp;
            res.clear();
            for (FileType f : allFile){
                temp = JSON.toJSONString(f);
                res.add(temp);
            }
            fileWriterUtil.writeJson(res,path,"filelevel-4t-simple");
        }
        if (ac.getSource() == button10){
            this.jf.dispose();
            new CloneClassifyUi(path);
        }
        if(ac.getSource() == button5){
            this.jf.dispose();
            new BeginUi();
        }
    }
}
