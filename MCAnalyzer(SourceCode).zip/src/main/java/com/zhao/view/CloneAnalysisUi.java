package com.zhao.view;
import com.zhao.service_cut.ServiceOperation;
import com.zhao.util.ProInfoUtil;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class CloneAnalysisUi implements ActionListener,ListSelectionListener{
    String path = "";
    int len;
    int current_version;
    int selectIndex;
    boolean flag = true;
    String[] allVersion;
    ProInfoUtil proInfoUtil = new ProInfoUtil();
    ServiceOperation serviceOperation = new ServiceOperation();
    int success = -1;
    private JFrame jf = new JFrame("single version");
    private Container container = jf.getContentPane();
    private ScrollPane scrollPane1 = new ScrollPane();//用这个来保证有滑块
    private JPanel panel1 = new JPanel();//控制边框
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private Dimension sc = toolkit.getScreenSize();
    private JLabel jLabel1 = new JLabel("Project version in this directory");
    private JTextField jTextField1 = new JTextField("");
    private JLabel jLabel2 = new JLabel("current project");
    private JLabel jLabel22 = new JLabel("xxx project");
    private JButton jButton1 = new JButton("next project");
    private JButton jButton11 = new JButton("previous project");
    private JLabel jLabel3 = new JLabel("Current Project Clone Pair Info Format");
    private JTextField jTextField3 = new JTextField("");
    private JLabel jLabel4 = new JLabel("Please select service identification information ");
    private JList list = new JList();
    private JTextField jTextField4 = new JTextField("");
    private JButton jButton2 = new JButton("Intra-Service Clone Lookup");
    private JButton jButton3 = new JButton("Clone lookup across services");
    private JButton jButton9 = new JButton("Return to previous menu");
    public CloneAnalysisUi(String path) {
        this.path = path;
        len = getProjectVersion(path).length;
        current_version = 0;
        allVersion = getProjectVersion(path);
        container.setLayout(null);
        jf.setSize(1300, 700);
        jf.setLocation((sc.width - 1000) / 2, (sc.height - 618) / 2);
        jf.setResizable(false);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jLabel1.setBounds(50, 50, 200, 30);
        jLabel1.setBackground(Color.lightGray);
        jLabel1.setForeground(Color.BLACK);
        jLabel1.setOpaque(true);
        jTextField1.setBounds(300,50,900,30);
        jTextField1.setText(proInfoUtil.showString(allVersion,0));
        jLabel2.setBounds(50, 100, 100, 30);
        jLabel2.setBackground(Color.lightGray);
        jLabel2.setForeground(Color.BLACK);
        jLabel2.setOpaque(true);
        jLabel22.setText(allVersion[current_version]);
        jLabel22.setBounds(200,100,150,30);
        jButton11.setBounds(400,100,100,30);
        jButton1.setBounds(520,100,100,30);
        jButton1.addActionListener(this);
        jButton11.addActionListener(this);
        if(current_version == 0){
            jButton11.setEnabled(false);
        }else if(current_version == (allVersion.length - 1)){
            jButton1.setEnabled(false);
        }
        jLabel3.setBounds(50,150,150,30);
        jLabel3.setBackground(Color.lightGray);
        jLabel3.setForeground(Color.BLACK);
        jLabel3.setOpaque(true);
        jTextField3.setBounds(50,200,900,30);
        jTextField3.setText(showCpString(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]),0));
        jLabel4.setBounds(50,250,250,30);
        jTextField4.setBounds(50,300,200,30);
        jTextField4.setText(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version])[0]);
        list.setBounds(50,350,200,200);
        list.setListData(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]));
        list.setSelectedIndex(0);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.addListSelectionListener(this);
        scrollPane1.setBounds(50,350,200,200);
        scrollPane1.add(list);
        panel1.setBorder(BorderFactory.createTitledBorder("Single version analysis option"));
        panel1.setLayout(null);
        panel1.setBounds(400,350,220,200);
        jButton2.setBounds(50,50,150,30);
        jButton3.setBounds(50,100,150,30);
        panel1.add(jButton2);
        panel1.add(jButton3);
        jButton2.addActionListener(this);
        jButton3.addActionListener(this);


        jButton9.setBounds(400,570,200,30);
        jButton9.addActionListener(this);

        panel1.add(jButton2);
        panel1.add(jButton3);
        container.add(jLabel1);
        container.add(jTextField1);
        container.add(jLabel2);
        container.add(jLabel22);
        container.add(jButton1);
        container.add(jButton11);
        container.add(jLabel3);
        container.add(jTextField3);
        container.add(jLabel4);
        container.add(jTextField4);
        container.add(jButton9);
        jf.add(scrollPane1);
        jf.add(panel1);
        if(allVersion.length == 1){
            jButton1.setEnabled(false);
            jButton11.setEnabled(false);
        }
    }
    @Override
    public void actionPerformed(ActionEvent ac) {
        if (ac.getSource() == this.jButton1){
            selectIndex = 0;
            current_version++;
            jLabel22.setText(allVersion[current_version]);
            jTextField1.setText(proInfoUtil.showString(allVersion,current_version));
            jTextField3.setText(showCpString(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]),0));
            flag = false;
            list.setListData(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]));
            list.setSelectedIndex(0);
            jTextField4.setText(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version])[selectIndex]);
            if(current_version >= 1){
                this.jButton11.setEnabled(true);
            }
            if(current_version == allVersion.length -1){
                this.jButton1.setEnabled(false);
            }
        }
        if(ac.getSource() == this.jButton11){
            selectIndex = 0;
            current_version--;
            jLabel22.setText(allVersion[current_version]);
            jTextField1.setText(proInfoUtil.showString(allVersion,current_version));
            jTextField3.setText(showCpString(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]),0));
            flag = false;
            list.setListData(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]));
            list.setSelectedIndex(0);
            jTextField4.setText(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version])[selectIndex]);
            if(current_version == 0){
                this.jButton11.setEnabled(false);
            }
            if(current_version <= (allVersion.length - 1)){
                this.jButton1.setEnabled(true);
            }
        }
        if(ac.getSource() == this.jButton2){
            success = -1;
            String s = "The project you are analyzing is  " + allVersion[current_version] + "  The clone identification information is《" +jTextField4.getText() + "》,This is one of the services in the project" +
                    "\n\nPlease confirm again (if the information is wrong, click to go back in the upper right corner). If the analysis is successful, the result is placed in  " + path + allVersion[current_version] + "\\analysisresult   Folder";
            int judge = JOptionPane.showConfirmDialog(null,s);
            if(judge == 0){
                success = serviceOperation.cutByServcie(path + "\\" + allVersion[current_version],selectIndex,1);
            }
            if(success == 1){
                winMessage("Analysis success");
            }else if(success == -1){
                winMessage("Analysis failed");
            }
        }
        if(ac.getSource() == this.jButton3){
            success = -1;
            String s = "The project you are analyzing is  " + path + "\\" + allVersion[current_version] + "  The clone identification information is《" +jTextField4.getText() + "》,This is one of the services in the project" +
                    "\n\nPlease confirm again (if the information is wrong, click to go back in the upper right corner). If the analysis is successful, the result is placed in  " + path + allVersion[current_version] + "\\analysisresult  Folder";
            int judge = JOptionPane.showConfirmDialog(null,s);
            if(judge == 0){
                success = serviceOperation.cutByServcie(path + "\\" + allVersion[current_version],selectIndex,2);
            }
            if(success == 1){
                winMessage("Analysis success");
            }else if(success == -1){
                winMessage("Analysis failed");
            }
        }
        if(ac.getSource() == jButton9){
            this.jf.dispose();
            new BeginUi();
        }
    }
    @Override
    public void valueChanged(ListSelectionEvent ls) {
        if(ls.getSource() == this.list){
            if(flag == false){
                flag = true;
                return;
            }else {
                selectIndex = list.getSelectedIndex();
                jTextField4.setText(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version])[selectIndex]);
                jTextField3.setText(showCpString(proInfoUtil.getCloneInfoToShow(path + "\\" + allVersion[current_version]),selectIndex));
            }
        }
    }
    public String[] getProjectVersion(String path){
        return proInfoUtil.projectVersion(path);
    }
    public String showCpString(String[] strings,int loc){
        int count = 0;
        String res = "";
        for(String s : strings){
            if(count == loc){
                res = res + "/ " + " 《" + s + "》 ";
            }else{
                res = res + "/ " + s;
            }
            count++;
        }
        return res.substring(1);
    }
    public static void winMessage(String str) {
        JOptionPane.showMessageDialog(null, str, "warning",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
