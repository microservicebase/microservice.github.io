package com.zhao.util;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class ProInfoUtil {
    FileReaderUtil fileReader = new FileReaderUtil();
    public String[] projectVersion(String path){
        File file = new File(path);
        return file.list();
    }
    public List<String> getAllService(String path){
        File file = new File(path);
        List<String> res = new ArrayList<>();
        for(String s : file.list()){
            res.add(s);
        }
        return res;
    }
    public String[] getCloneInfoToShow(String path){
        File file = new File(path + "\\cloneresult");
        String clone3 = "";
        for(String s : file.list()){
            if (s.contains("functions-blind-clones-0.30")){
                clone3 = s;
                break;
            }
        }
        List<List<String>> res = fileReader.getClonePair(path + "\\cloneresult" + "\\" + clone3);

        String temp = res.get(0).get(1);
        String info = temp.split(" ")[1].split("=")[1];
        String[] cloneInfo = info.substring(1,info.length()-1).split("/");

        return cloneInfo;
    }
    public List<List<String>> finishedPro(String path){
        String[] all = projectVersion(path);
        List<List<String>> res = new ArrayList<>();
        List<String> finished = new ArrayList<>();
        List<String> unfinished = new ArrayList<>();
        int flagRes = 0;
        int flagInAndCro = 0;
        for(String s1 : all){
            File file1 = new File(path + "\\" + s1);
            String[] content1 = file1.list();
            flagRes = 0;
            for(String s2 : content1){
                if(s2.equals("analysisresult")){
                    flagRes = 1;
                }
            }
            if(flagRes == 0){
                unfinished.add(s1);
            }else if(flagRes == 1){
                flagInAndCro = 0;
                File file2 = new File(path + "\\" + s1 + "\\" + "analysisresult");
                String[] content2 = file2.list();
                for(String s3 : content2){
                    if(s3.contains("crossService")){
                        flagInAndCro ++;
                    }
                    if (s3.contains("withinService")) {
                        flagInAndCro++;
                    }
                }
                if(flagInAndCro == 2){
                    finished.add(s1);
                }else{
                    unfinished.add(s1);
                }
            }
        }
        res.add(finished);
        res.add(unfinished);
        return res;
    }
    public  List<List<String>> matchFunName(List<List<String>> baselists,List<List<String>> funlists){
        for(List<String> baseClone : baselists){
            String[] temp1 = baseClone.get(1).trim().split(" ");
            String[] temp2 = baseClone.get(2).trim().split(" ");
            String first = temp1[0] + " " +  temp1[1] + " " + temp1[2] + " " +  temp1[3];
            String second = temp2[0] + " " +  temp2[1] + " " + temp2[2] + " " +  temp2[3];
            for(List<String> baseFun : funlists){
                String temp3 = baseFun.get(0);
                if(temp3.contains(first)){
                    String funName = getFunName(baseFun.get(1));
                    String funVar = getFunVar(baseFun.get(1));
                    baseClone.add(4,funName );
                    baseClone.add(5,funVar);
                    break;
                }
            }
            for(List<String> baseFun : funlists){
                String temp3 = baseFun.get(0);
                if(temp3.contains(second)){
                    String funName = getFunName(baseFun.get(1));
                    String funVar = getFunVar(baseFun.get(1));
                    baseClone.add(6,funName);
                    baseClone.add(7,funVar);
                    break;
                }
            }
        }
        return baselists;
    }
    public  String getFunName(String s){
        String[] strings = s.split(" ");
        String  result = "";
        int i = 0;
        int k = 0;
        while(k < strings.length){//
            if(strings[k].contains("(")){
                i = k;
                break;
            }
            k++;
        }
        k = 0;
        while(k < i){
            result  = result + strings[k] + " ";
            k++;
        }
        return result;
    }

    public  String getFunVar(String s){
        String[] strings = s.split(" ");
        String  result = "";
        int i = 0;
        int k = 0;
        while(k < strings.length){//
            if(strings[k].contains("(")){
                i = k;
                break;
            }
            k++;
        }
        k = strings.length;
        while( i < k){
            result  = result + strings[i] + " ";
            i++;
        }
        return result;
    }
    public String showString(String[] strings,int loc){
        int count = 0;
        String res = "";
        for(String s : strings){
            if(count == loc){
                res = res + "  " + "《" + s + "》";
            }else{
                res = res + "  " + s;
            }
            count++;
        }
        return res;
    }
    public String getProName(String path){
        String separator = File.separator;
        String[] temp = path.split("\\\\");
        String name = temp[temp.length - 1];
        return name;
    }
}
