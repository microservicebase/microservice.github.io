package com.zhao.util;
import com.sun.scenario.effect.impl.sw.java.JSWBlend_SRC_OUTPeer;

import java.io.*;
import java.util.List;
public class FileWriterUtil {
    public int writeFile(String path, String fileName, List<List<String>> content){
        File newPath = new File(path);
        int success = 1;
        if(!newPath.exists()){
            newPath.mkdir();
        }
        File resFile = new File(path + "\\" + fileName);
        if(resFile.exists()) resFile.delete();
        if (!resFile.exists()) {
            try {
                resFile.createNewFile();
                FileOutputStream fos = new FileOutputStream(resFile);
                OutputStreamWriter osw = new OutputStreamWriter(fos,"UTF-8");
                BufferedWriter bw = new BufferedWriter(osw);
                for (List<String> rl : content) {
                    for (String s : rl) {
                        bw.write(s + "\n");
                        bw.flush();
                    }
                }
                bw.close();
                osw.close();
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
                success = -1;
            }
        }
        return success;
    }
    public void writeResult(List<List<String>> result,String path,String proName,String serType,String fileName) {
        String p1 = null;
        File f = null;
        String p2 = path + f.separator  + proName + f.separator + "analysisresult" + f.separator + "cochange_" + proName + f.separator + serType;
        File dir = new File(p2);
        dir.mkdirs();
        p1 = p2 + f.separator + fileName + ".xml";
        try {
            File file = new File(p1);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fos = null;
            OutputStreamWriter osw = null;
            BufferedWriter bw = null;
            fos = new FileOutputStream(file);
            osw = new OutputStreamWriter(fos, "UTF-8");
            bw = new BufferedWriter(osw);
            for (List<String> rl : result) {
                for (String s : rl) {
                    bw.write(s + "\n");
                    bw.flush();
                }
            }
            bw.close();
            osw.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void writeJson(List<String> res,String path,String fileName){
        File f = null;
        String p1 = path + f.separator + "classify";
        String p2 = p1 + f.separator + fileName + ".txt";

        File dir = new File(p1);
        dir.mkdir();

        try{
            File file = new File(p2);
            if (file.exists()) file.delete();
            if(!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = null;
            OutputStreamWriter osw = null;
            BufferedWriter bw = null;
            fos = new FileOutputStream(file);
            osw = new OutputStreamWriter(fos, "UTF-8");
            bw = new BufferedWriter(osw);
            for (String s : res) {
                bw.write(s + "\n");
                bw.flush();
            }
            bw.close();
            osw.close();
            fos.close();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
