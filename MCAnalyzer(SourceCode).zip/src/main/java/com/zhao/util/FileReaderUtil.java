package com.zhao.util;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class FileReaderUtil {
    public List<List<String>> getClonePair(String path){
        List<List<String>> res = new ArrayList<>();
        List<String> clonePair = new ArrayList<>();
        List<String> content = new ArrayList<>();
        File file = new File(path);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String s = null;
            while((s = reader.readLine()) != null){
                content.add(s);
            }
        } catch (Exception e) {
            System.out.println("在getClonePair方法中有错误");
            e.printStackTrace();
        }
        String begin = null;
        for(String s : content){
            if(s.contains("<clone n") && begin == null){
                clonePair.add(s);
                begin = s;
            }else if(s.contains("</clone>") && begin != null){
                clonePair.add(s);
                res.add(clonePair);
                clonePair = new ArrayList<String>();
                begin = null;
                continue;
            }else if(begin != null){
                clonePair.add(s);
            }
        }
        return res;
    }
    public List<List<String>> getClonePairByType(String path,int cType,String fType){
        List<List<String>> res = new ArrayList<>();
        List<String> before = new ArrayList<>();
        List<String> clonePair = new ArrayList<>();
        File file1 = new File(path);
        File file2 = null;
        for(String s:file1.list()){
            if (s.contains(fType)){
                file2 = new File(path + "\\" + s);
                break;
            }
        }
        BufferedReader reader = null;
        int flagBegin = 0;
        int flagEnd = 0;
        try {
            reader = new BufferedReader(new FileReader(file2));
            String s = null;
            while((s = reader.readLine()) != null){
                if(s.contains("type" + cType + "_clone")){
                    flagBegin = 1;
                }
                if(s.contains("type" + (cType+1) + "_clone")){
                    flagEnd = 1;
                }
                if(flagBegin == 1 && flagEnd == 0){
                    before.add(s);
                }
            }
        } catch (Exception e) {
            System.out.println("getClonePairByType里出了问题");
            e.printStackTrace();
        }
        String begin = null;
        for(String s : before){
            if(s.contains("<clone n") && begin == null){
                clonePair.add(s);
                begin = s;
            }else if(s.contains("</clone>") && begin != null){
                clonePair.add(s);
                res.add(clonePair);
                clonePair = new ArrayList<String>();
                begin = null;
                continue;
            }else if(begin != null){
                clonePair.add(s);
            }
        }
        return res;
    }
    public List<List<String>> readFun(String path){
        File file1 = new File(path);
        String path_fun = "";
        for(String temp : file1.list()){
            if (temp.contains("functions.xml")){
                path_fun = path + "\\" + temp;
                break;
            }
        }
        File file2 = new File(path_fun);
        String s = null;
        String begin=null;
        List<List<String>> result = new ArrayList<>();
        List<String> function = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file2), "UTF-8"));//构造一个BufferedReader类来读取文件
            while ((s = br.readLine()) != null) {//使用readLine方法，一次读一行
                if(s.contains("<source")){
                    begin = s;
                }else if(!s.contains("<source") && !s.contains("</source>")){
                    function.add(s);
                }else if(s.contains("</source>")){
                    function.add(0,begin);
                    function.add(s);
                    result.add(function);
                    begin = null;
                    function = new ArrayList<>();
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  result;
    }
}
