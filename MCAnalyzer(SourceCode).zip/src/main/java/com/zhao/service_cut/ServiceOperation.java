package com.zhao.service_cut;
import com.zhao.util.FileReaderUtil;
import com.zhao.util.FileWriterUtil;
import com.zhao.util.ProInfoUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class ServiceOperation {
    FileReaderUtil fileReaderUtil = new FileReaderUtil();
    FileWriterUtil fileWriterUtil = new FileWriterUtil();
    ProInfoUtil proInfoUtil = new ProInfoUtil();
    List<String> allService = new ArrayList<>();
    String proName = null;
    int totalPair = 0;
    List<List<String>> exist = new ArrayList<>();
    public int cutByServcie(String path,int service_index,int type){
        String cloneResPath = path + "\\cloneresult";
        File files = new File(cloneResPath);
        String[] fileList = files.list();
        List<List<String>> clone1 = new ArrayList<>();
        List<List<String>> clone2 = new ArrayList<>();
        List<List<String>> clone3  = new ArrayList<>();
        allService.clear();
        proName = null;
        int success = -1;
        for(String file : fileList){
            if(file.contains("functions-clones-0.00")){
                clone1 = fileReaderUtil.getClonePair(cloneResPath + "\\" + file);
            }else if(file.contains("functions-blind-clones-0.00")){
                clone2 = fileReaderUtil.getClonePair(cloneResPath + "\\" + file);
            }else if(file.contains("functions-blind-clones-0.30")){
                clone3 = fileReaderUtil.getClonePair(cloneResPath + "\\" + file);
            }
        }
        allService = proInfoUtil.getAllService(path+ "\\sourcecode");
        proName = path.split("\\\\")[path.split("\\\\").length - 1];
        if(type == 1){
            totalPair = 0;
            List<List<String>> ISClone_1 = serviceJudge(clone1,service_index,type,"type1_clone");
            List<List<String>> ISClone_2 = serviceJudge(clone2,service_index,type,"type2_clone");
            List<List<String>> ISClone_3 = serviceJudge(clone3,service_index,type,"type3_clone");
            List<List<String>> ISClone_all = new ArrayList<>();
            List<String> title1 = new ArrayList<>();
            List<String> end1 = new ArrayList<>();
            String temp1 = "";
            for(String ser : allService){
                temp1 = temp1 + ser + "  ";
            }
            title1.add("<withinservice>");
            title1.add("<baseinfo projectname=\"" + proName + "\" " + "allclone=\"" + totalPair + "\" " + "servicenumber=\"" + allService.size() + "\"/>");
            title1.add("<serviceinfo allservice=\"" + temp1 + "\"/>\n");
            end1.add("</withinservice>");
            ISClone_all.add(title1);
            for (List<String> ls : ISClone_1){
                ISClone_all.add(ls);
            }
            for (List<String> ls : ISClone_2){
                ISClone_all.add(ls);
            }
            for (List<String> ls : ISClone_3){
                ISClone_all.add(ls);
            }
            ISClone_all.add(end1);
            success = fileWriterUtil.writeFile(path + "\\analysisresult",proName + "_withinService.xml",ISClone_all);
        }

        if(type == 2){
            totalPair = 0;
            List<List<String>> CSClone_1 = serviceJudge(clone1,service_index,type,"type1_clone");
            List<List<String>> CSClone_2 = serviceJudge(clone2,service_index,type,"type2_clone");
            List<List<String>> CSClone_3 = serviceJudge(clone3,service_index,type,"type3_clone");
            List<List<String>> CSClone_all = new ArrayList<>();
            List<String> title2 = new ArrayList<>();
            List<String> end2 = new ArrayList<>();
            String temp2 = "";
            for(String ser : allService){
                temp2 = temp2 + ser + "  ";
            }
            title2.add("<crossservice>");
            title2.add("<baseinfo projectname=\"" + proName + "\" " + "allclone=\"" + totalPair + "\" " + "servicenumber=\"" + allService.size() + "\"/>");
            title2.add("<serviceinfo allservice=\"" + temp2 + "\"/>\n");
            end2.add("</crossservice>");
            CSClone_all.add(title2);
            for (List<String> ls : CSClone_1){
                CSClone_all.add(ls);
            }
            for (List<String> ls : CSClone_2){
                CSClone_all.add(ls);
            }
            for (List<String> ls : CSClone_3){
                CSClone_all.add(ls);
            }
            CSClone_all.add(end2);
            success = fileWriterUtil.writeFile(path + "\\analysisresult",proName + "_crossService.xml",CSClone_all);
        }
        return success;
    }

    public List<List<String>> serviceJudge(List<List<String>> clone,int service_index,int type,String type_info){
        List<List<String>> res = new ArrayList<>();
        int count = 0;
        List<String> add_info = new ArrayList<>();
        List<String> service_info = new ArrayList<>();
        for (List<String> list : clone){
            int flag = 1;
            for (List<String> ex : exist){
                if (ex.get(2).equals(list.get(2)) && ex.get(1).equals(list.get(1))){
                    flag = 0;
                    break;
                }
            }
            if (flag == 0){
                continue;
            }
            String service1 = list.get(1).split(" ")[1].split("=")[1].split("/")[service_index];
            String service2 = list.get(2).split(" ")[1].split("=")[1].split("/")[service_index];

            if((service1.equals(service2)) && (type == 1)){//进入这里就不会进入另一个分支
                if(!service_info.contains(service1)){
                    service_info.add(service1);
                }
                count ++;
                res.add(list);
            }
            if(!(service1.equals(service2)) && (type == 2)){
                if(!service_info.contains(service1)){
                    service_info.add(service1);
                }
                if(!service_info.contains(service2)){
                    service_info.add(service2);
                }
                count ++;
                res.add(list);
                exist.add(list);
            }
        }
        totalPair = totalPair + count;
        String s = "";
        List<String> end = new ArrayList<>();
        if(type == 1){
            s = "";
            for(String ser : service_info){
                s = s + ser + "  ";
            }
            add_info.add("<within_" + type_info + " " + "percentage=\"" +  ((float)service_info.size())/((float)allService.size()) *100 + "%\" " +
                    "number=\"" + count + "\" " + "services=\"" + s + "\">");
            res.add(0,add_info);
            end.add("</within_" + type_info + ">\n");
            res.add(end);
        }else{
            s = "";
            for(String ser : service_info){
                s = s + ser + "  ";
            }
            add_info.add("<cross_" + type_info + " " + "percentage=\"" +  ((float)service_info.size())/((float)allService.size()) *100 + "%\" " +
                    "number=\"" + count + "\" " + "services=\"" + s + "\"" + ">");
            res.add(0,add_info);
            end.add("</cross_" + type_info + ">\n");
            res.add(end);
        }
        return res;
    }
}
