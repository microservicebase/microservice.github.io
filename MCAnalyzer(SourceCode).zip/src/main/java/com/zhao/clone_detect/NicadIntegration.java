package com.zhao.clone_detect;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
public class NicadIntegration {
    public int clearPro(String path,int type){
        File file = new File(path);
        File[] all = file.listFiles();
        if (type == 1){
            for(File f : all){
                if (f.getName().equals("sourcecode")){
                    continue;
                }else{
                    if(f.isFile()){
                        f.delete();
                    }
                    else{
                        for(File temp : f.listFiles()){{
                            temp.delete();
                        }}
                        f.delete();
                    }
                }
            }
        }else if(type == 2){
            for(File f : all){
                if (f.getName().equals("sourcecode") || f.getName().equals("cloneresult")){
                    continue;
                }else{
                    if(f.isFile()){
                        f.delete();
                    }else{
                        for(File temp : f.listFiles()){{
                            temp.delete();
                        }}
                        f.delete();
                    }
                }
            }
        }
        return 1;
    }
    public int modfiybash(String path,String content,String type){
        File file = new File(path);
        List<String> all = new ArrayList<>();
        String add = "./nicad6 functions java " + content + " " + type;
        String s;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            while((s = br.readLine()) != null){
                if(s.contains("./nicad")){
                    all.add(add);
                }else{
                    all.add(s);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
        file.delete();
        try{
            File file_new = new File(path);
            if (!file_new.exists()) {
                file_new.createNewFile();
            }
            FileOutputStream fos = null;
            OutputStreamWriter osw = null;
            BufferedWriter bw = null;
            fos = new FileOutputStream(file_new);
            osw = new OutputStreamWriter(fos, "UTF-8");
            bw = new BufferedWriter(osw);
            for (String ss : all){
                bw.write(ss + "\n");
                bw.flush();
            }
            bw.close();
            osw.close();
            fos.close();
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
        return 1;
    }
    public int run_bat(String path){
        Process ps = null;
        try {
            ps = Runtime.getRuntime().exec(path + "\\CygWin\\Cygwin.bat");
            ps.waitFor();
        } catch (IOException e) {
            System.out.println("Cygwin.bat !!!");
            e.printStackTrace();
            return 2;
        } catch (InterruptedException e) {
            System.out.println("Cygwin.bat !!!");
            e.printStackTrace();
            return 2;
        }
        int i = ps.exitValue();
        if(i == 0){
            return 1;
        }else{
            return 2;
        }
    }
    public int cutFile(String path){
        File f1 = new File(path);
        File f2 = new File(path + "\\cloneresult");
        if (!f2.exists()){
            f2.mkdir();
        }
        int count = 0;
        try {
            for (File temp1 : f1.listFiles()){
                if (temp1.getName().equals("sourcecode_functions.xml")){
                    Files.move(temp1.toPath(),f2.toPath().resolve(temp1.getName()),StandardCopyOption.ATOMIC_MOVE);
                    count++;
                }
                if (temp1.getName().equals("sourcecode_functions-clones")){
                    for(File temp2 : temp1.listFiles()){
                        if (temp2.getName().equals("sourcecode_functions-clones-0.00.xml")){
                            Files.move(temp2.toPath(),f2.toPath().resolve(temp2.getName()),StandardCopyOption.ATOMIC_MOVE);
                            count++;
                        }
                    }
                }
                if(temp1.getName().equals("sourcecode_functions-blind-clones")){
                    for (File temp3 : temp1.listFiles()){
                        if (temp3.getName().equals("sourcecode_functions-blind-clones-0.00.xml")){
                            Files.move(temp3.toPath(),f2.toPath().resolve(temp3.getName()),StandardCopyOption.ATOMIC_MOVE);
                            count++;
                        }
                        if (temp3.getName().equals("sourcecode_functions-blind-clones-0.30.xml")){
                            Files.move(temp3.toPath(),f2.toPath().resolve(temp3.getName()),StandardCopyOption.ATOMIC_MOVE);
                            count++;
                        }
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        clearPro(path,2);
        return count;
    }
}
