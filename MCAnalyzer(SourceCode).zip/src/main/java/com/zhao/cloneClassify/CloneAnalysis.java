package com.zhao.cloneClassify;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.support.hsf.HSFJSONUtils;
import com.zhao.bean.CloneType;
import com.zhao.bean.FileType;
import com.alibaba.fastjson.JSON;
import com.zhao.util.FileWriterUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;

public class CloneAnalysis {
    private String path;
    private List<File> filelevel = new ArrayList<>();
    private List<File> codelevel  = new ArrayList<>();
    private List<FileType> fileTypes = new ArrayList<>();
    private List<CloneType> cloneTypes = new ArrayList<>();
    private List<List<String>> CP = new ArrayList<>();
    FileWriterUtil fileWriterUtil = new FileWriterUtil();
    List<String> tags = new ArrayList<>();


    public CloneAnalysis(String path){
        this.path = path;
        init();
        fileLevelAnalysis();
        codeLevelAnalysis();

    }

    public int fileLevelAnalysis(){
        List<List<String>> pair1 = new ArrayList<>();
        List<List<String>> pair2 = new ArrayList<>();
        List<List<String>> pair3 = new ArrayList<>();
        List<List<String>> pair13 = new ArrayList<>();
        List<List<String>> pair23 = new ArrayList<>();
        List<List<String>> pair12 = new ArrayList<>();
        List<List<String>> pairother = new ArrayList<>();
        String proOfFile1 = "";
        String proOfFile2 = "";
        String proOfFile3 = "";
        int[] count1 = {0,0,0,0};
        int[] count2 = {0,0,0,0};
        int[] count3 = {0,0,0,0};


        List<String> res = new ArrayList<>();

        List<FileType> file1 = new ArrayList<>();
        List<FileType> file2 = new ArrayList<>();
        List<FileType> file3 = new ArrayList<>();

        for(File temp: filelevel){
            String s = null;
            try {
                BufferedReader reader = new BufferedReader(new FileReader(temp));
                while((s = reader.readLine()) != null){
                    FileType fileType = JSON.parseObject(s,FileType.class);
                    if(fileType == null){
                        System.out.println(s);
                        System.out.println(temp.getName());
                        continue;
                    }
                    fileTypes.add(fileType);
                    if (fileType.getDataType().equals("core")){
                        file1.add(fileType);
                    }else if(fileType.getDataType().equals("support")){
                        file2.add(fileType);
                    }else if (fileType.getDataType().equals("other")){
                        file3.add(fileType);
                    }
                }

            }catch (Exception e){
            }
        }

        for (List<String> ls : CP){
            int flag1 = 0;
            int flag2 = 0;
            int flag3 = 0;
            for(FileType fileType : file1){
                if (ls.get(0).contains(fileType.getFilePath())) flag1++;
                if (ls.get(1).contains(fileType.getFilePath())) flag1++;
                if (flag1 == 2){
                    String proName = fileType.getFilePath().split("\\\\")[6];
                    if (! proOfFile1.contains(proName)){
                        proOfFile1 = proOfFile1 + "---" + proName;
                    }
                }
            }
            for(FileType fileType : file2){
                if (ls.get(0).contains(fileType.getFilePath())) flag2++;
                if (ls.get(1).contains(fileType.getFilePath())) flag2++;
                if (flag2 == 2){
                    String proName = fileType.getFilePath().split("\\\\")[6];
                    if (! proOfFile2.contains(proName)){
                        proOfFile2 = proOfFile2 + "---" + proName;
                    }
                }
            }
            for(FileType fileType : file3){
                if (ls.get(0).contains(fileType.getFilePath())) flag3++;
                if (ls.get(1).contains(fileType.getFilePath())) flag3++;
                if (flag3 == 2){
                    String proName = fileType.getFilePath().split("\\\\")[6];
                    if (! proOfFile3.contains(proName)){
                        proOfFile3 = proOfFile3 + "---" + proName;
                    }
                }
            }

            if (flag1 == 2){
                pair1.add(ls);
                count1[0]++;
                if(checkCloneType(ls) == 1){
                    count1[1] ++;
                }else if(checkCloneType(ls) == 2){
                    count1[2] ++;
                }else if (checkCloneType(ls) == 3){
                    count1[3] ++;
                }
                if (checkCloneType(ls) == -1){
                    System.out.println("flag1");
                }
            }else if(flag2 == 2){
                pair2.add(ls);
                count2[0]++;
                if(checkCloneType(ls) == 1){
                    count2[1] ++;
                }else if(checkCloneType(ls) == 2){
                    count2[2] ++;
                }else if (checkCloneType(ls) == 3){
                    count2[3] ++;
                }
                if (checkCloneType(ls) == -1){
                    System.out.println("flag2");
                }
            }else if(flag3 == 2){
                pair3.add(ls);
                count3[0]++;
                if(checkCloneType(ls) == 12){
                    count3[1] ++;
                }else if(checkCloneType(ls) == 2){
                    count3[2] ++;
                }else if (checkCloneType(ls) == 3){
                    count3[3] ++;
                }
                if (checkCloneType(ls) == -1){
                    System.out.println("flag3");
                }
            }else if(flag1 == 1 && flag2 == 2){
                pair12.add(ls);
            }else if(flag2 == 1 && flag3 == 1){
                pair23.add(ls);
            }else if(flag1 == 1 && flag3 == 1){
                pair13.add(ls);
            }else if(flag1 == 1 && flag2 == 1){
                pair12.add(ls);
            }else{
                pairother.add(ls);
            }
        }


        String s = "，data_process：" + file1.size() + "；" + "data_related：" + file2.size() + "；" + "data_irrevlent：" + file3.size() + "";
        res.add(s + "\n");
        s = "file type in clnoe----1" + pair1.size() + "----2" + pair2.size() + "----3" + pair3.size() + "----12" + pair12.size() + "----13" + pair13.size() + "----23" + pair23.size() + "----other" + pairother.size();
        res.add(s + "\n");
        s = "\ndata_process：\n";
        res.add(s);
        res.add(proOfFile1 + "\n");
        for (FileType fileType:file1){
            res.add(fileType.getFileName() + "----" + fileType.getFilePath());
        }

        s = "\ndata_related：\n";
        res.add(s);
        res.add(proOfFile2 + "\n");
        for (FileType fileType:file2){
            res.add(fileType.getFileName() + "----" + fileType.getFilePath());
        }

        s = "\ndata_irrevalent：\n";
        res.add(s);
        res.add(proOfFile3 + "\n");
        for (FileType fileType:file3){
            res.add(fileType.getFileName() + "----" + fileType.getFilePath());
        }

        s = "=======================================================================================================\n";
        res.add(s);

        s = "\ndata_process：" + count1[0] + "type1：" + count1[1] + "type2：" + count1[2] + "type3：" + count1[3] +"\n";
        res.add(s);
        int count = 1;
        for (List<String> list:pair1){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\ndata_related：" + count2[0] + "type1：" + count2[1] + "type2：" + count2[2] + "type3：" + count2[3] +"\n";
        res.add(s);
         count = 1;
        for (List<String> list:pair2){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\ndata_irrevalent：" + count3[0] + "type1：" + count3[1] + "type2：" + count3[2] + "type3：" + count3[3] +"对\n";
        res.add(s);
        count = 1;
        for (List<String> list:pair3){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\ndata_process && data_related ：\n";
        res.add(s);
        count = 1;
        for (List<String> list:pair12){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\ndata_process && data_irrevalent：\n";
        res.add(s);
        count = 1;
        for (List<String> list:pair13){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\ndata_related && data_irrevalent ：\n";
        res.add(s);
        count = 1;
        for (List<String> list:pair23){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        s = "\n other：\n";
        res.add(s);
        count = 1;
        for (List<String> list:pairother){
            s = "clone_" + count;
            count++;
            res.add(s);
            res.add(list.get(0));
            res.add(list.get(1));
        }

        fileWriterUtil.writeJson(res,path + "\\res","filelevel");


        return 0;
    }

    public int codeLevelAnalysis(){

        List<String> tagsPro = new ArrayList<>();
        List<List<CloneType>> all = new ArrayList<>();
        List<String> res = new ArrayList<>();

        Collections.sort(tags);
        Collections.sort(cloneTypes);

        int clusterNum = 0;
        int count = 0;
        for (String s : tags){
            List<CloneType> temp = new ArrayList<>();
            tagsPro.add("containing servcies：");

            for (CloneType c : cloneTypes){
                if (c.getCloneType().equals(s)){
                    temp.add(c);
                    if(tagsPro.get(count) == null){
                        tagsPro.set(count,c.getCloneInfo().get(0).split("\\\\")[6]);
                    }else if ((c.getCloneInfo().get(0).split("\\\\")[6]!=null) && !(tagsPro.get(count).contains(c.getCloneInfo().get(0).split("\\\\")[6]))){
                        String proTemp = tagsPro.get(count);
                        proTemp = proTemp + "---" + c.getCloneInfo().get(0).split("\\\\")[6];
                        tagsPro.set(count,proTemp);
                    }

                }
            }
            clusterNum = clusterNum + temp.size();
            all.add(temp);
            count ++;
        }

        String s = null;
        s = "clone pair：" + CP.size() + ", contain" + clusterNum + "clusters" +", split to " + tags.size() + "categories\n";
        res.add(s);

        int index = 0;
        int num = 0;
        s = "";
        for (String s1 :tags){
            num = 0;
            for (CloneType c1 : all.get(index)){
                num = num + c1.getCloneInfo().size()/2;
            }
            index ++;

            s = s + s1 + "contain:" + num + " clone pairs； ";
        }
        s = s + "\n";
        res.add(s);

        index = 0;
        for (String s1 :tags){
            s = s1 +"contain clone clusters"+ all.get(index).size() +" they are :\n";
            res.add(s);
            res.add(tagsPro.get(index) + "\n");
            num = 1;
            for (CloneType c1 : all.get(index)){
                for (int i = 0;i < c1.getCloneInfo().size() - 1;i = i + 2){
                    s = "==id:" + num + "==";
                    res.add(s);
                    res.add(c1.getCloneInfo().get(i) );
                    res.add(c1.getCloneInfo().get(i + 1) + "\n");
                    num++;
                }
            }
            index++;
        }

        fileWriterUtil.writeJson(res,path + "\\res","code level");

        return 0;
    }


    public void init(){
        File file1 = new File(path);
        File[] files = file1.listFiles();

        for(File f : files){
            if(!f.isDirectory()){
                File temp = f;
                if (f.getName().contains("filelevel")){
                    if(filelevel.contains(f)){
                        continue;
                    }else {
                        filelevel.add(temp);
                    }
                }else if(f.getName().contains("codelevel")){
                    if(codelevel.contains(f)){
                        continue;
                    }else {
                        codelevel.add(temp);
                    }
                }
            }
        }

        for (File temp:codelevel){
            String s = null;
            try {
                BufferedReader reader = new BufferedReader(new FileReader(temp));

                while((s = reader.readLine()) != null){
                    CloneType cloneType= JSONObject.parseObject(s,CloneType.class);
                    if(cloneType == null){
                        System.out.println(temp.getName());
                        System.out.println(s);
                        continue;
                    }
                    List<String> cloneInfo = cloneType.getCloneInfo();
                    if (cloneInfo == null){
                        System.out.println(cloneType.toString());
                        continue;
                    }

                    for (int i = 0; i < cloneInfo.size() - 1;i = i + 2){
                        List<String> pair = new ArrayList<>();
                        pair.add(cloneInfo.get(i));
                        pair.add(cloneInfo.get(i + 1));
                        CP.add(pair);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        for(File temp: codelevel){
            String s = null;
            try {
                BufferedReader reader = new BufferedReader(new FileReader(temp));
                while((s = reader.readLine()) != null){
                    CloneType cloneType = JSON.parseObject(s,CloneType.class);
                    if(cloneType == null){
                        System.out.println(s);
                        System.out.println(temp.getName());
                        continue;
                    }
                    cloneTypes.add(cloneType);
                    if(! tags.contains(cloneType.getCloneType())){
                        if(cloneType.getCloneType() == null){
                            cloneType.setCloneType("null");
                        }
                        tags.add(cloneType.getCloneType());
                    }
                }

            }catch (Exception e){
            }
        }

    }

    public  int checkCloneType(List<String> pair){
        int type = -1;
        for (CloneType cloneType:cloneTypes){
            List<String> clonePair = cloneType.getCloneInfo();
            for (int i = 0; i < clonePair.size()-1; i = i + 2){
                if (clonePair.get(i).contains(pair.get(0)) && clonePair.get(i + 1).contains(pair.get(1))){
                    type = Integer.parseInt(cloneType.getTypeId());
                    break;
                }
            }
            if (type != -1){
                break;
            }
        }

        return type;
    }





}
