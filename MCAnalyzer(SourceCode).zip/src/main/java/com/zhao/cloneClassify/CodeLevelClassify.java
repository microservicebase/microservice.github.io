package com.zhao.cloneClassify;
import com.zhao.bean.CloneType;
import com.zhao.util.FileReaderUtil;
import java.util.ArrayList;
import java.util.List;

public class CodeLevelClassify {
    String path;
    int count = 0;
    List<CloneType> init = new ArrayList<>();
    FileReaderUtil fileReaderUtil = new FileReaderUtil();


    public List<CloneType> getInitClone(String path){
        this.path = path;

        init = new ArrayList<>();
        count = 0;

        List<List<String>> clone1 = new ArrayList<>();
        List<List<String>> clone2 = new ArrayList<>();
        List<List<String>> clone3 = new ArrayList<>();

        clone1 = fileReaderUtil.getClonePairByType(path + "//analysisresult",1,"cross");
        clone2 = fileReaderUtil.getClonePairByType(path + "//analysisresult",2,"cross");
        clone3 = fileReaderUtil.getClonePairByType(path + "//analysisresult",3,"cross");

        getCloneCluster(clone1,"1");
        getCloneCluster(clone2,"2");
        getCloneCluster(clone3,"3");

        return init;
    }

    private void getCloneCluster(List<List<String>> clone,String typeId){
        List<String> input = new ArrayList<>();
        List<CloneType> thisType = new ArrayList<>();
        int i = 0;

        while(input.size()/2 < clone.size() && i < clone.size()){
            String c1 = getPath(path,clone.get(i).get(1));
            String c2 = getPath(path,clone.get(i).get(2));

            int exis = 0;
            for(int j = 0;j < input.size();j = j + 2){
                String temp = input.get(j) + input.get(j + 1);
                if (temp.contains(c1) && temp.contains(c2)){
                    exis = 1;
                }
            }

            //当前这对克隆对并没有出现过，就要新建CloneType
            if(exis == 0){
                input.add(c1);
                input.add(c2);

                CloneType ct = new CloneType();
                List<String> cluster = new ArrayList<>();
                List<String> info = new ArrayList<>();
                info.add(c1);
                info.add(c2);
                cluster.add(c1);
                cluster.add(c2);
                ct.setId(count + "");
                ct.setTypeId(typeId);
                count ++ ;
                int find = 0;

                while (true){
                    for (int k = 0;k < clone.size();k++){
                        String temp1 = getPath(path,clone.get(k).get(1));
                        String temp2 = getPath(path,clone.get(k).get(2));

                        int flag_input = 0;
                        for (int k1 = 0;k1 < input.size();k1 = k1 + 2){
                            String temp = input.get(k1) + input.get(k1 + 1);
                            if( temp.equals(temp1 + temp2)){
                                flag_input = 1;
                            }
                        }

                        if (flag_input == 1){//如果当前克隆对已经存在于input中，则跳过它
                            continue;
                        }else{//否则检查这个克隆对是否是聚类相关
                            for (int k2 = 0;k2 < input.size();k2 = k2 + 2){
                                String temp = input.get(k2) + input.get(k2 + 1);
                                if(temp.contains(temp1) && !temp.contains(temp2)){
                                    info.add(temp1);
                                    info.add(temp2);
                                    if(!cluster.contains(temp2)){
                                        cluster.add(temp2);
                                    }
                                    find ++;
                                    break;
                                }else if (!temp.contains(temp1) && temp.contains(temp2)){
                                    info.add(temp1);
                                    info.add(temp2);
                                    if(!cluster.contains(temp1)){
                                        cluster.add(temp1);
                                    }
                                    find ++;
                                    break;
                                }
                            }
                        }
                    }
                    input.clear();
                    if (thisType.size() > 0){
                        for (CloneType cloneType : thisType){
                            for(String s : cloneType.getCloneInfo()){
                                input.add(s);
                            }
                        }
                    }
                    for(String s : info){
                        input.add(s);
                    }

                    if (find == 0){
                        break;
                    }
                    find = 0;
                }
                ct.setCloneInfo(info);
//                for (String in: info){
//                    System.out.println("***" + in);
//                }
                ct.setClusterInfo(cluster);
//                for (String in1: cluster){
//                    System.out.println("###" + in1);
//                }
                thisType.add(ct);
                init.add(ct);
            }
            i++;
        }
    }

    private String getPath(String path,String info){
        String temp1;
        String temp2;
        String res = path ;
        int loc = 0;
        int start,end;

        temp1 = info.split(" ")[1].split("=")[1];
        temp1 = temp1.substring(1,temp1.length() - 1);
        loc = temp1.indexOf("sourcecode");
        temp1 = temp1.substring(loc);

        temp2 = info.split(" ")[2].split("=")[1];
        temp2 = temp2.substring(1,temp2.length() - 1);
        start = Integer.parseInt(temp2);

        temp2 = info.split(" ")[3].split("=")[1];
        temp2 = temp2.substring(1,temp2.length() - 1);
        end = Integer.parseInt(temp2);

        for(String s:temp1.split("/")){
            res = res + "\\"  + s;
        }
        res = res + "----" + start + "----" + end;

        return  res;

    }

}
