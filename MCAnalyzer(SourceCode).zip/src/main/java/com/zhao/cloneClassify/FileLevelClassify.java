package com.zhao.cloneClassify;

import com.zhao.bean.FileType;
import com.zhao.util.FileReaderUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileLevelClassify {
    String path;
    int count = 0;
    List<FileType> init = new ArrayList<>();
    List<List<String>> clone = new ArrayList<>();
    FileReaderUtil fileReaderUtil = new FileReaderUtil();

    public List<FileType> getInitFile(String path){
        init = new ArrayList<>();
        count = 0;

        File file = new File(path + "//analysisresult");
        File[] files = file.listFiles();

        String cross = "";
        for(File f : files){
            if(f.getName().contains("crossService")){
                cross = f.getName();
                break;
            }
        }
        clone = fileReaderUtil.getClonePair(path + "//analysisresult//" + cross);
        getJavaFileInfo(path);
        return init;
    }

    private void getJavaFileInfo(String path){
        File dir = new File(path);
        File[] files = dir.listFiles();
        if(files != null){
            for(int i = 0;i < files.length;i++){
                String fileName = files[i].getName();
                if(files[i].isDirectory()){
                    getJavaFileInfo(files[i].getAbsolutePath());
                }else if(fileName.endsWith(".java")){
                    for(List<String> l : clone){
                        String s1 = tokenize(files[i].getAbsolutePath(),"\\\\");
                        String temp = "";
                        temp = l.get(1).split(" ")[1];
                        String s2 = tokenize(temp.substring(temp.length()/4,temp.length() - 1),"/");
                        temp = l.get(2).split(" ")[1];
                        String s3 = tokenize(temp.substring(temp.length()/4,temp.length() - 1),"/");

                        if(s1.contains(s2) || s1.contains(s3)){
                            int flag = 0;
                            for (FileType ft : init){
                                if(ft.getFilePath().contains(files[i].getAbsolutePath())){
                                    flag = 1;
                                    break;
                                }
                            }

                            if(flag == 0){
                                FileType fileType = new FileType();
                                fileType.setId(count + "");
                                count++;
                                fileType.setFileName(fileName);
                                fileType.setDataType("");
                                fileType.setFilePath(files[i].getAbsolutePath());
                                init.add(fileType);
                            }
                        }
                    }
                }else{
                    continue;
                }
            }
        }
    }

    private String tokenize(String s,String split){
        String res = "";
        String[] temp = s.split(split);
        for(String s1 : temp){
            res = res + s1;
        }
        return res;
    }





}
