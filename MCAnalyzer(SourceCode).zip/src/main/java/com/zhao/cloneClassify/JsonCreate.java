package com.zhao.cloneClassify;

import com.alibaba.fastjson.JSON;
import com.zhao.bean.CloneType;
import com.zhao.bean.Data;
import com.zhao.bean.FileType;
import com.zhao.util.FileWriterUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class JsonCreate {
    String path;
    List<FileType> fileTypeList = new ArrayList<>();
    List<CloneType> cloneTypeList = new ArrayList<>();
    List<Data> dataList = new ArrayList<>();
    List<String> res = new ArrayList<>();
    FileWriterUtil fileWriterUtil = new FileWriterUtil();

    public JsonCreate(String path) {
        this.path = path;
        Create();
        res.clear();
        FileLevelAnalysis(dataList);
        CodeLevelAnalysis(dataList);
        fileWriterUtil.writeJson(res,path + "\\res","Statistics.txt");
    }

    public void Create(){
        File file = new File(path);
        File[] files = file.listFiles();

        for(File f : files){
            if (f.getName().contains("filelevel")){
                readFile(f,"filelevel");
            }else if(f.getName().contains("codelevel")){
                readFile(f,"codelevel");
            }
        }

        int id = 0;
        for(CloneType cloneType : cloneTypeList){
            int len = cloneType.getCloneInfo().size();
            for(int i = 0; i < len - 1; i = i + 2){
                Data data = new Data();
                data.setId(id + "");

                List<String> clonePair = new ArrayList<>();
                clonePair.add(cloneType.getCloneInfo().get(i));
                clonePair.add(cloneType.getCloneInfo().get(i + 1));
                data.setClone_pair(clonePair);

                data.setClone_type(cloneType.getTypeId());
                List<String> file_mark = new ArrayList<>();
                for (FileType fileType : fileTypeList){
                    if (cloneType.getCloneInfo().get(i).contains(fileType.getFilePath())){
                        file_mark.add(fileType.getDataType());
                    }
                    if (cloneType.getCloneInfo().get(i + 1).contains(fileType.getFilePath())){
                        file_mark.add(fileType.getDataType());
                    }
                    if (file_mark.size()  == 2){
                        break;
                    }
                }

                data.setFile_mark(file_mark);
                data.setCluster_id(cloneType.getNote() + ":" + cloneType.getId());
                data.setClone_mark(cloneType.getCloneType());

                dataList.add(data);
                id++;
            }
        }

        for (Data data : dataList){
            res.add(JSON.toJSONString(data));
        }
        fileWriterUtil.writeJson(res,path + "\\res","AllCloneData.txt");
    }

    public void readFile(File file,String type){
        String s = null;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            while((s = br.readLine()) != null){
                if(type.equals("filelevel")){
                    FileType fileType = JSON.parseObject(s,FileType.class);
                    if (fileType != null){
                        fileTypeList.add(fileType);
                    }

                }else if(type.equals("codelevel")){
                    CloneType cloneType = JSON.parseObject(s,CloneType.class);
                    if (cloneType != null){
                        cloneType.setNote(file.getName().split("-")[0]);
                        cloneTypeList.add(cloneType);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void FileLevelAnalysis(List<Data> dataList){
        int[] DPF = new int[4];
        int[] DRF = new int[4];
        int[] DIF = new int[4];
        int[] SPE = new int[4];

        for (Data data : dataList){
            if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                DPF[0]++;
                if (data.getClone_type().equals("1")){
                    DPF[1]++;
                }else if (data.getClone_type().equals("2")){
                    DPF[2]++;
                }else if(data.getClone_type().equals("3")){
                    DPF[3]++;
                }
            }else if(data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                DRF[0]++;
                if (data.getClone_type().equals("1")){
                    DRF[1]++;
                }else if (data.getClone_type().equals("2")){
                    DRF[2]++;
                }else if(data.getClone_type().equals("3")){
                    DRF[3]++;
                }
            }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                DIF[0]++;
                if (data.getClone_type().equals("1")){
                    DIF[1]++;
                }else if (data.getClone_type().equals("2")){
                    DIF[2]++;
                }else if(data.getClone_type().equals("3")){
                    DIF[3]++;
                }
            }else{
                SPE[0]++;
                if (data.getClone_type().equals("1")){
                    SPE[1]++;
                }else if (data.getClone_type().equals("2")){
                    SPE[2]++;
                }else if(data.getClone_type().equals("3")){
                    SPE[3]++;
                }
            }
        }
        res.add("文件级别信息统计（信息格式为：克隆对总数--一型克隆--二型克隆--三型克隆）\n");
        System.out.println("DPF   " + DPF[0] + "--" + DPF[1] + "--"+ DPF[2] + "--" + DPF[3]);
        System.out.println("DRF   " + DRF[0] + "--" + DRF[1] + "--"+ DRF[2] + "--" + DRF[3]);
        System.out.println("DIF   " + DIF[0] + "--" + DIF[1] + "--"+ DIF[2] + "--" + DIF[3]);
        System.out.println("SPE   " + SPE[0] + "--" + SPE[1] + "--"+ SPE[2] + "--" + SPE[3]);
        res.add("DPF   " + DPF[0] + "--" + DPF[1] + "--"+ DPF[2] + "--" + DPF[3] + "\n");
        res.add("DRF   " + DRF[0] + "--" + DRF[1] + "--"+ DRF[2] + "--" + DRF[3] + "\n");
        res.add("DIF   " + DIF[0] + "--" + DIF[1] + "--"+ DIF[2] + "--" + DIF[3] + "\n");
        res.add("SPE   " + SPE[0] + "--" + SPE[1] + "--"+ SPE[2] + "--" + SPE[3] + "\n");

    }
    public void CodeLevelAnalysis(List<Data> dataList){
        int[] text_1 = new int[7];
        int[] text_2 = new int[7];
        int[] config_1 = new int[7];
        int[] config_2 = new int[7];
        int[] config_3 = new int[7];
        int[] func_1 = new int[7];
        int[] func_2 = new int[7];
        int[] func_3 = new int[7];
        int[] other_1 = new int[7];
        int[] other_2 = new int[7];
        int[] special = new int[7];

        for (Data data : dataList){
            if(data.getClone_mark().equals("wb-1")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    text_1[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    text_1[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    text_1[2]++;
                }
                if(data.getClone_type().equals("1")){
                    text_1[3]++;
                }else if (data.getClone_type().equals("2")){
                    text_1[4]++;
                }else if (data.getClone_type().equals("3")){
                    text_1[5]++;
                }
                text_1[6]++;
            }else if(data.getClone_mark().equals("wb-2")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    text_2[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    text_2[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    text_2[2]++;
                }
                if(data.getClone_type().equals("1")){
                    text_2[3]++;
                }else if (data.getClone_type().equals("2")){
                    text_2[4]++;
                }else if (data.getClone_type().equals("3")){
                    text_2[5]++;
                }
                text_2[6]++;
            }else if(data.getClone_mark().contains("pz-1")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    config_1[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    config_1[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    config_1[2]++;
                }
                if(data.getClone_type().equals("1")){
                    config_1[3]++;
                }else if (data.getClone_type().equals("2")){
                    config_1[4]++;
                }else if (data.getClone_type().equals("3")){
                    config_1[5]++;
                }
                config_1[6]++;
            }else if(data.getClone_mark().contains("pz-2")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    config_2[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    config_2[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    config_2[2]++;
                }
                if(data.getClone_type().equals("1")){
                    config_2[3]++;
                }else if (data.getClone_type().equals("2")){
                    config_2[4]++;
                }else if (data.getClone_type().equals("3")){
                    config_2[5]++;
                }
                config_2[6]++;
            }else if(data.getClone_mark().contains("pz-3")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    config_3[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    config_3[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    config_3[2]++;
                }
                if(data.getClone_type().equals("1")){
                    config_3[3]++;
                }else if (data.getClone_type().equals("2")){
                    config_3[4]++;
                }else if (data.getClone_type().equals("3")){
                    config_3[5]++;
                }
                config_3[6]++;
            }else if(data.getClone_mark().contains("yw-1")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    func_1[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    func_1[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    func_1[2]++;
                }
                if(data.getClone_type().equals("1")){
                    func_1[3]++;
                }else if (data.getClone_type().equals("2")){
                    func_1[4]++;
                }else if (data.getClone_type().equals("3")){
                    func_1[5]++;
                }
                func_1[6]++;
            }else if(data.getClone_mark().contains("yw-2")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    func_2[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    func_2[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    func_2[2]++;
                }
                if(data.getClone_type().equals("1")){
                    func_2[3]++;
                }else if (data.getClone_type().equals("2")){
                    func_2[4]++;
                }else if (data.getClone_type().equals("3")){
                    func_2[5]++;
                }
                func_2[6]++;
            }else if(data.getClone_mark().contains("yw-3")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    func_3[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    func_3[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    func_3[2]++;
                }
                if(data.getClone_type().equals("1")){
                    func_3[3]++;
                }else if (data.getClone_type().equals("2")){
                    func_3[4]++;
                }else if (data.getClone_type().equals("3")){
                    func_3[5]++;
                }
                func_3[6]++;
            }else if(data.getClone_mark().contains("qt-1")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    other_1[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    other_1[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    other_1[2]++;
                }
                if(data.getClone_type().equals("1")){
                    other_1[3]++;
                }else if (data.getClone_type().equals("2")){
                    other_1[4]++;
                }else if (data.getClone_type().equals("3")){
                    other_1[5]++;
                }
                other_1[6]++;
            }else if(data.getClone_mark().contains("qt-2")){
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    other_2[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    other_2[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    other_2[2]++;
                }
                if(data.getClone_type().equals("1")){
                    other_2[3]++;
                }else if (data.getClone_type().equals("2")){
                    other_2[4]++;
                }else if (data.getClone_type().equals("3")){
                    other_2[5]++;
                }
                other_2[6]++;
            }else{
                if(data.getFile_mark().get(0).equals("core") && data.getFile_mark().get(1).equals("core")){
                    special[0] ++;
                }else if (data.getFile_mark().get(0).equals("support") && data.getFile_mark().get(1).equals("support")){
                    special[1]++;
                }else if (data.getFile_mark().get(0).equals("other") && data.getFile_mark().get(1).equals("other")){
                    special[2]++;
                }
                if(data.getClone_type().equals("1")){
                    special[3]++;
                }else if (data.getClone_type().equals("2")){
                    special[4]++;
                }else if (data.getClone_type().equals("3")){
                    special[5]++;
                }
                special[6]++;
            }
        }
        res.add("方法级别信息统计（信息格式为：DPFClone--DRFClone--DIFClone--type1--type2--type3--total）\n");
        System.out.println("text_1   " + text_1[0] + "--" + text_1[1] + "--"+ text_1[2] + "--" + text_1[3] + "--"+ text_1[4] + "--" + text_1[5] + "--"+ text_1[6]);
        System.out.println("text_2   " + text_2[0] + "--" + text_2[1] + "--"+ text_2[2] + "--" + text_2[3] + "--"+ text_2[4] + "--" + text_2[5] + "--"+ text_2[6]);
        System.out.println("config_1   " + config_1[0] + "--" + config_1[1] + "--"+ config_1[2] + "--" + config_1[3] + "--"+ config_1[4] + "--" + config_1[5] + "--"+ config_1[6]);
        System.out.println("config_2   " + config_2[0] + "--" + config_2[1] + "--"+ config_2[2] + "--" + config_2[3] + "--"+ config_2[4] + "--" + config_2[5] + "--"+ config_2[6]);
        System.out.println("config_3   " + config_3[0] + "--" + config_3[1] + "--"+ config_3[2] + "--" + config_3[3] + "--"+ config_3[4] + "--" + config_3[5] + "--"+ config_3[6]);
        System.out.println("func_1   " + func_1[0] + "--" + func_1[1] + "--"+ func_1[2] + "--" + func_1[3] + "--"+ func_1[4] + "--" + func_1[5] + "--"+ func_1[6]);
        System.out.println("func_2   " + func_2[0] + "--" + func_2[1] + "--"+ func_2[2] + "--" + func_2[3] + "--"+ func_2[4] + "--" + func_2[5] + "--"+ func_2[6]);
        System.out.println("func_3   " + func_3[0] + "--" + func_3[1] + "--"+ func_3[2] + "--" + func_3[3] + "--"+ func_3[4] + "--" + func_3[5] + "--"+ func_3[6]);
        System.out.println("other_1   " + other_1[0] + "--" + other_1[1] + "--"+ other_1[2] + "--" + other_1[3] + "--"+ other_1[4] + "--" + other_1[5] + "--"+ other_1[6]);
        System.out.println("other_2   " + other_2[0] + "--" + other_2[1] + "--"+ other_2[2] + "--" + other_2[3] + "--"+ other_2[4] + "--" + other_2[5] + "--"+ other_2[6]);
        System.out.println("special   " + special[0] + "--" + special[1] + "--"+ special[2] + "--" + special[3] + "--"+ special[4] + "--" + special[5] + "--"+ special[6]);
        res.add("text_1   " + text_1[0] + "--" + text_1[1] + "--"+ text_1[2] + "--" + text_1[3] + "--"+ text_1[4] + "--" + text_1[5] + "--"+ text_1[6] + "\n");
        res.add("text_2   " + text_2[0] + "--" + text_2[1] + "--"+ text_2[2] + "--" + text_2[3] + "--"+ text_2[4] + "--" + text_2[5] + "--"+ text_2[6]  + "\n");
        res.add("config_1   " + config_1[0] + "--" + config_1[1] + "--"+ config_1[2] + "--" + config_1[3] + "--"+ config_1[4] + "--" + config_1[5] + "--"+ config_1[6]  + "\n");
        res.add("config_2   " + config_2[0] + "--" + config_2[1] + "--"+ config_2[2] + "--" + config_2[3] + "--"+ config_2[4] + "--" + config_2[5] + "--"+ config_2[6]  + "\n");
        res.add("config_3   " + config_3[0] + "--" + config_3[1] + "--"+ config_3[2] + "--" + config_3[3] + "--"+ config_3[4] + "--" + config_3[5] + "--"+ config_3[6]  + "\n");
        res.add("func_1   " + func_1[0] + "--" + func_1[1] + "--"+ func_1[2] + "--" + func_1[3] + "--"+ func_1[4] + "--" + func_1[5] + "--"+ func_1[6]  + "\n");
        res.add("func_2   " + func_2[0] + "--" + func_2[1] + "--"+ func_2[2] + "--" + func_2[3] + "--"+ func_2[4] + "--" + func_2[5] + "--"+ func_2[6]  + "\n");
        res.add("func_3   " + func_3[0] + "--" + func_3[1] + "--"+ func_3[2] + "--" + func_3[3] + "--"+ func_3[4] + "--" + func_3[5] + "--"+ func_3[6]  + "\n");
        res.add("other_1   " + other_1[0] + "--" + other_1[1] + "--"+ other_1[2] + "--" + other_1[3] + "--"+ other_1[4] + "--" + other_1[5] + "--"+ other_1[6]  + "\n");
        res.add("other_2   " + other_2[0] + "--" + other_2[1] + "--"+ other_2[2] + "--" + other_2[3] + "--"+ other_2[4] + "--" + other_2[5] + "--"+ other_2[6]  + "\n");
        res.add("special   " + special[0] + "--" + special[1] + "--"+ special[2] + "--" + special[3] + "--"+ special[4] + "--" + special[5] + "--"+ special[6] + "\n");
    }




}
