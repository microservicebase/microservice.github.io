import com.zhao.cloneClassify.JsonCreate;

public class test {
    public static void main(String[] args) {
        JsonCreate jsonCreate = new JsonCreate("D:\\MyCodingRoom\\IdeaWorkSpace\\MCAnalyzer\\CygWin\\2_projects\\1allres");

    }
}
